from flask import Blueprint, request, jsonify
from models import User, Expense

user_routes = Blueprint('user_routes', __name__)
expense_routes = Blueprint('expense_routes', __name__)

# In-memory storage for simplicity
users = {}
expenses = []

# Create User
@user_routes.route('/user', methods=['POST'])
def create_user():
    data = request.json
    email = data['email']
    name = data['name']
    mobile = data['mobile']

    if email in users:
        return jsonify({"error": "User already exists"}), 400

    user = User(email, name, mobile)
    users[email] = user
    return jsonify({"message": "User created successfully"}), 201

# Add Expense
@expense_routes.route('/expense', methods=['POST'])
def add_expense():
    data = request.json
    amount = data['amount']
    participants = data['participants']
    split_type = data['split_type']
    split_details = data['split_details']

    # Validate split details
    if split_type == 'percentage' and sum(split_details.values()) != 100:
        return jsonify({"error": "Percentages must sum to 100"}), 400

    expense = Expense(amount, participants, split_type, split_details)
    expenses.append(expense)

    # Distribute expenses among users
    for user_email in participants:
        if user_email not in users:
            return jsonify({"error": f"User {user_email} not found"}), 404
        users[user_email].expenses.append(expense)

    return jsonify({"message": "Expense added successfully"}), 201

# Get User Expenses
@expense_routes.route('/expense/<email>', methods=['GET'])
def get_user_expenses(email):
    if email not in users:
        return jsonify({"error": "User not found"}), 404

    user = users[email]
    user_expenses = [{'amount': e.amount, 'split': e.split_details} for e in user.expenses]
    return jsonify({"expenses": user_expenses}), 200

# Get All Expenses
@expense_routes.route('/expenses', methods=['GET'])
def get_all_expenses():
    all_expenses = [{'amount': e.amount, 'split': e.split_details} for e in expenses]
    return jsonify({"expenses": all_expenses}), 200
