# Daily Expenses Sharing Application

## Setup Instructions
1. Install dependencies
```bash
pip install -r requirements.txt
```

2. Run the application
```bash
python app.py
```

3. API Endpoints:
- `POST /user`: Create a user
- `POST /expense`: Add an expense
- `GET /expense/<email>`: Get individual user's expenses
- `GET /expenses`: Get all expenses
