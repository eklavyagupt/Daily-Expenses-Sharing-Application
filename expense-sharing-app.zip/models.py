class User:
    def __init__(self, email, name, mobile):
        self.email = email
        self.name = name
        self.mobile = mobile
        self.expenses = []

class Expense:
    def __init__(self, amount, participants, split_type, split_details):
        self.amount = amount
        self.participants = participants
        self.split_type = split_type  # 'equal', 'exact', or 'percentage'
        self.split_details = split_details  # How much each participant owes
